package demo1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ListDemo {
	/*
	 * public static void main(String[] args) { List<String> countries = new
	 * ArrayList<>(); countries.add("India"); countries.add("Nepal"); StringBuilder
	 * s1 = new StringBuilder("FMR"); countries.add(s1.toString());
	 * System.out.println(countries); }
	 */
	public static void main(String[] args) {
		List<Account> accounts = new ArrayList<>();
		Account account = null;
		for (int i = 0; i < 5; i++) {
			account = new Account();
			account.number = String.valueOf((int) Math.ceil(Math.random() * 1000));
			account.balance=(float) Math.ceil(Math.random() * 1000);
			accounts.add(account);
		}
		System.out.println(accounts);
		// sorting
		accounts.sort(new Comparator<Account>() {
			@Override
			public int compare(Account account1, Account account2) {
				System.out.println("com###");
//				return account1.number.equals(account2.number) ? 1 : -1;
//				return account1.balance > account2.balance ? 1:-1;
				return (int)(account1.balance - account2.balance );
			}
		});
		System.out.println(accounts);
	}
}
