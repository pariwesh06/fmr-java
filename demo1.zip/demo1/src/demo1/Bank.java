package demo1;

import java.util.Arrays;

public class Bank {
	public static void main(String[] args) {
		// demo1();
		loops();
	}

	private static void loops() {
		int arr[] = new int[50];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = i;
		}
		System.out.println(Arrays.toString(arr));
		match(arr, 13);
	}

	private static boolean match(int[] arr, int number) {
		boolean result = false;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == number) {
				result = true;
				break;
			}
		}
		return result;
	}
	
	private static boolean match1(int[] arr, int number) {
		for (int i = 0; i < arr.length; i++) {
			return arr[i] == number;
		}
		return false;
	}

	private static void demo1() {
		System.out.println("Hello Java");
		Account account = new Account(); // reference, object
		account.balance = 6000;
		Account account2 = account;
		account.number = new String("abc");
		if (account.balance > 5000 && account.number.equals("abc")) {
			System.out.println("account matched");
		}
		// Account[] accounts = { account };
		Account[] accounts = new Account[3];
		accounts[0] = account;
	}
}
