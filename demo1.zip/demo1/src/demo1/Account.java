package demo1;

import java.util.Date;

enum TYPE{
	SAVINGS, FIXED_DEPOSIT, CURRENT, DEMAT
}

public class Account {
	String number;
	float balance;
	TYPE type;
	Date openingDate;
//	age; computed value
	@Override
	public String toString() {
		return new StringBuilder("number=").append(number)
				.append(", balance").append(balance).toString();
	}
}
