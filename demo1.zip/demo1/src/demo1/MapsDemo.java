package demo1;

import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

public class MapsDemo {
	public static void main(String[] args) {
		Map<String, String[]> continents = new TreeMap<>();
		String[] countries = {"India", "Pakistan"};
		continents.put("Asia", countries);
		System.out.println(Arrays.toString(continents.get("Asia")));
		continents.remove("Asia");
		continents.clear();
//		continents.put("Asia", "Pakistan");
//		System.out.println(continents);
	}
}
