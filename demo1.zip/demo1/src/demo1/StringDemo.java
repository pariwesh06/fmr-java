package demo1;

public class StringDemo {
	public static void main(String[] args) {
		String s1 = "FMR";
		StringBuilder s2 = new StringBuilder("FMR");
		System.out.println(s2);
		s2.append(s1).append("Bangalore");
		System.out.println(s2);
//		String s3 = "FMR";
//		System.out.println(s1==s2);
	}
}
